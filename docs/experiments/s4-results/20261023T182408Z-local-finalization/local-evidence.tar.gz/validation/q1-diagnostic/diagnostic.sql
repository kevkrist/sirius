LOAD '/home/ubuntu/sirius/build/s4-final/build/s4-final-pair/final/sirius.duckdb_extension';
SET gpu_execution = false;
SET max_dynamic_filter_bloom_bytes_per_gpu = 268435456;
SET dynamic_filter_domain_coverage_threshold = 0.9;
SET enable_dynamic_filter = true;
SET enable_dynamic_filter_multi_partition = true;
CREATE VIEW lineitem AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s3c-data/tpch_parquet_sf100/lineitem/part.0.parquet','/home/ubuntu/sirius-s3c-data/tpch_parquet_sf100/lineitem/part.1.parquet','/home/ubuntu/sirius-s3c-data/tpch_parquet_sf100/lineitem/part.2.parquet','/home/ubuntu/sirius-s3c-data/tpch_parquet_sf100/lineitem/part.3.parquet','/home/ubuntu/sirius-s3c-data/tpch_parquet_sf100/lineitem/part.4.parquet','/home/ubuntu/sirius-s3c-data/tpch_parquet_sf100/lineitem/part.5.parquet']);
CALL pin_table('/home/ubuntu/sirius-s3c-data/tpch_parquet_sf100/lineitem/*.parquet', name='lineitem', tier='gpu', cols=['l_returnflag','l_linestatus','l_quantity','l_extendedprice','l_discount','l_tax','l_shipdate'], compression=false);
SET gpu_execution = true;

.mode csv
.headers on
SET gpu_execution=false;
.once /home/ubuntu/sirius/build/s4-final/build/s4-local-validation/q1-diagnostic/types.csv
DESCRIBE (select
    l_returnflag,
    l_linestatus,
    sum(l_quantity) as sum_qty,
    sum(l_extendedprice) as sum_base_price,
    sum(l_extendedprice * (1 - l_discount)) as sum_disc_price,
    sum(l_extendedprice * (1 - l_discount) * (1 + l_tax)) as sum_charge,
    avg(l_quantity) as avg_qty,
    avg(l_extendedprice) as avg_price,
    avg(l_discount) as avg_disc,
    count(*) as count_order
from
    lineitem
where
    l_shipdate <= date '1995-08-19'
group by
    l_returnflag,
    l_linestatus
order by
    l_returnflag,
    l_linestatus);
.once /home/ubuntu/sirius/build/s4-final/build/s4-local-validation/q1-diagnostic/cpu.csv
select
    l_returnflag,
    l_linestatus,
    sum(l_quantity) as sum_qty,
    sum(l_extendedprice) as sum_base_price,
    sum(l_extendedprice * (1 - l_discount)) as sum_disc_price,
    sum(l_extendedprice * (1 - l_discount) * (1 + l_tax)) as sum_charge,
    avg(l_quantity) as avg_qty,
    avg(l_extendedprice) as avg_price,
    avg(l_discount) as avg_disc,
    count(*) as count_order
from
    lineitem
where
    l_shipdate <= date '1995-08-19'
group by
    l_returnflag,
    l_linestatus
order by
    l_returnflag,
    l_linestatus;

SET gpu_execution=true;
.once /home/ubuntu/sirius/build/s4-final/build/s4-local-validation/q1-diagnostic/gpu-first.csv
select
    l_returnflag,
    l_linestatus,
    sum(l_quantity) as sum_qty,
    sum(l_extendedprice) as sum_base_price,
    sum(l_extendedprice * (1 - l_discount)) as sum_disc_price,
    sum(l_extendedprice * (1 - l_discount) * (1 + l_tax)) as sum_charge,
    avg(l_quantity) as avg_qty,
    avg(l_extendedprice) as avg_price,
    avg(l_discount) as avg_disc,
    count(*) as count_order
from
    lineitem
where
    l_shipdate <= date '1995-08-19'
group by
    l_returnflag,
    l_linestatus
order by
    l_returnflag,
    l_linestatus;

.once /home/ubuntu/sirius/build/s4-final/build/s4-local-validation/q1-diagnostic/gpu-repeat.csv
select
    l_returnflag,
    l_linestatus,
    sum(l_quantity) as sum_qty,
    sum(l_extendedprice) as sum_base_price,
    sum(l_extendedprice * (1 - l_discount)) as sum_disc_price,
    sum(l_extendedprice * (1 - l_discount) * (1 + l_tax)) as sum_charge,
    avg(l_quantity) as avg_qty,
    avg(l_extendedprice) as avg_price,
    avg(l_discount) as avg_disc,
    count(*) as count_order
from
    lineitem
where
    l_shipdate <= date '1995-08-19'
group by
    l_returnflag,
    l_linestatus
order by
    l_returnflag,
    l_linestatus;
