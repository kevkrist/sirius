SET gpu_execution = false;
SET max_dynamic_filter_bloom_bytes_per_gpu = 268435456;
SET dynamic_filter_domain_coverage_threshold = 0.9;
SET enable_dynamic_filter = true;
SET enable_dynamic_filter_multi_partition = true;
CREATE VIEW lineitem AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s3c-data/tpch_parquet_sf100/lineitem/part.0.parquet','/home/ubuntu/sirius-s3c-data/tpch_parquet_sf100/lineitem/part.1.parquet','/home/ubuntu/sirius-s3c-data/tpch_parquet_sf100/lineitem/part.2.parquet','/home/ubuntu/sirius-s3c-data/tpch_parquet_sf100/lineitem/part.3.parquet','/home/ubuntu/sirius-s3c-data/tpch_parquet_sf100/lineitem/part.4.parquet','/home/ubuntu/sirius-s3c-data/tpch_parquet_sf100/lineitem/part.5.parquet']);
CALL pin_table('/home/ubuntu/sirius-s3c-data/tpch_parquet_sf100/lineitem/*.parquet', name='lineitem', tier='gpu', cols=['l_returnflag','l_linestatus','l_quantity','l_extendedprice','l_discount','l_tax','l_shipdate'], compression=false);
SET gpu_execution = true;
