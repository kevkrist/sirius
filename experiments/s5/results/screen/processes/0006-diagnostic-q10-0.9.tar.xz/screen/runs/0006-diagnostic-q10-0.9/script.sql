.bail on
.echo off
.mode json
.timer off
LOAD '/home/ubuntu/sirius-s5-four-gpu/sirius-duckdb/build/release/extension/sirius/sirius.duckdb_extension';
SET gpu_execution=false;
SET enable_duckdb_fallback=false;
SET enable_dynamic_filter=true;
SET enable_dynamic_filter_multi_partition=true;
SET max_dynamic_filter_bloom_bytes_per_gpu=268435456;
SET dynamic_filter_domain_coverage_threshold=0.9;
CREATE VIEW customer AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/customer/part.0.parquet']);
CREATE VIEW lineitem AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.0.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.1.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.2.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.3.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.4.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.5.parquet']);
CREATE VIEW nation AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/nation/part.0.parquet']);
CREATE VIEW orders AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/orders/part.0.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/orders/part.1.parquet']);
CREATE VIEW part AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/part/part.0.parquet']);
CREATE VIEW partsupp AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/partsupp/part.0.parquet']);
CREATE VIEW region AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/region/part.0.parquet']);
CREATE VIEW supplier AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/supplier/part.0.parquet']);
CALL pin_table('/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/customer/*.parquet', name='customer', tier='gpu', cols=['c_custkey','c_name','c_acctbal','c_address','c_phone','c_comment','c_nationkey'], compression=false, unique_cols=>['c_custkey']);
CALL pin_table('/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/*.parquet', name='lineitem', tier='gpu', cols=['l_orderkey','l_extendedprice','l_discount','l_returnflag'], compression=false);
CALL pin_table('/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/nation/*.parquet', name='nation', tier='gpu', cols=['n_nationkey','n_name'], compression=false, unique_cols=>['n_nationkey']);
CALL pin_table('/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/orders/*.parquet', name='orders', tier='gpu', cols=['o_custkey','o_orderkey','o_orderdate'], compression=false, unique_cols=>['o_orderkey']);
.once "/home/ubuntu/sirius-s5-four-gpu/build/s5-four-gpu-results/screen/runs/0006-diagnostic-q10-0.9/schema.json"
DESCRIBE select
  c.c_custkey,
  c.c_name,
  sum(l.l_extendedprice * (1 - l.l_discount)) as revenue,
  c.c_acctbal,
  n.n_name,
  c.c_address,
  c.c_phone,
  c.c_comment
from
  customer c,
  orders o,
  lineitem l,
  nation n
where
  c.c_custkey = o.o_custkey
  and l.l_orderkey = o.o_orderkey
  and o.o_orderdate >= date '1994-03-01'
  and o.o_orderdate < date '1994-06-01'
  and l.l_returnflag = 'R'
  and c.c_nationkey = n.n_nationkey
group by
  c.c_custkey,
  c.c_name,
  c.c_acctbal,
  c.c_phone,
  n.n_name,
  c.c_address,
  c.c_comment
order by
  revenue desc
limit 20;
.once "/home/ubuntu/sirius-s5-four-gpu/build/s5-four-gpu-results/screen/runs/0006-diagnostic-q10-0.9/settings.json"
SELECT current_setting('enable_duckdb_fallback') AS fallback, current_setting('enable_dynamic_filter') AS enabled, current_setting('enable_dynamic_filter_multi_partition') AS multipartition, current_setting('max_dynamic_filter_bloom_bytes_per_gpu')::BIGINT AS cap, current_setting('dynamic_filter_domain_coverage_threshold') AS coverage;
SET gpu_execution=true;
.print S5_BEGIN_0
.timer on 9
.once "/home/ubuntu/sirius-s5-four-gpu/build/s5-four-gpu-results/screen/runs/0006-diagnostic-q10-0.9/result-0.json"
select
  c.c_custkey,
  c.c_name,
  sum(l.l_extendedprice * (1 - l.l_discount)) as revenue,
  c.c_acctbal,
  n.n_name,
  c.c_address,
  c.c_phone,
  c.c_comment
from
  customer c,
  orders o,
  lineitem l,
  nation n
where
  c.c_custkey = o.o_custkey
  and l.l_orderkey = o.o_orderkey
  and o.o_orderdate >= date '1994-03-01'
  and o.o_orderdate < date '1994-06-01'
  and l.l_returnflag = 'R'
  and c.c_nationkey = n.n_nationkey
group by
  c.c_custkey,
  c.c_name,
  c.c_acctbal,
  c.c_phone,
  n.n_name,
  c.c_address,
  c.c_comment
order by
  revenue desc
limit 20;
.timer off
.print S5_END_0
.print S5_COMPLETE
