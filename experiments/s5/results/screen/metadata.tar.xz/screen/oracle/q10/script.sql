.bail on
.echo off
.mode json
.timer off
CREATE VIEW customer AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/customer/part.0.parquet']);
CREATE VIEW lineitem AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.0.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.1.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.2.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.3.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.4.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.5.parquet']);
CREATE VIEW nation AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/nation/part.0.parquet']);
CREATE VIEW orders AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/orders/part.0.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/orders/part.1.parquet']);
CREATE VIEW part AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/part/part.0.parquet']);
CREATE VIEW partsupp AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/partsupp/part.0.parquet']);
CREATE VIEW region AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/region/part.0.parquet']);
CREATE VIEW supplier AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/supplier/part.0.parquet']);
.once "/home/ubuntu/sirius-s5-four-gpu/build/s5-four-gpu-results/screen/oracle/q10/schema.json"
DESCRIBE select
  c.c_custkey,
  c.c_name,
  sum(l.l_extendedprice * (1 - l.l_discount)) as revenue,
  c.c_acctbal,
  n.n_name,
  c.c_address,
  c.c_phone,
  c.c_comment
from
  customer c,
  orders o,
  lineitem l,
  nation n
where
  c.c_custkey = o.o_custkey
  and l.l_orderkey = o.o_orderkey
  and o.o_orderdate >= date '1994-03-01'
  and o.o_orderdate < date '1994-06-01'
  and l.l_returnflag = 'R'
  and c.c_nationkey = n.n_nationkey
group by
  c.c_custkey,
  c.c_name,
  c.c_acctbal,
  c.c_phone,
  n.n_name,
  c.c_address,
  c.c_comment
order by
  revenue desc
limit 20;
.print S5_BEGIN_0
.timer on 9
.once "/home/ubuntu/sirius-s5-four-gpu/build/s5-four-gpu-results/screen/oracle/q10/result-0.json"
select
  c.c_custkey,
  c.c_name,
  sum(l.l_extendedprice * (1 - l.l_discount)) as revenue,
  c.c_acctbal,
  n.n_name,
  c.c_address,
  c.c_phone,
  c.c_comment
from
  customer c,
  orders o,
  lineitem l,
  nation n
where
  c.c_custkey = o.o_custkey
  and l.l_orderkey = o.o_orderkey
  and o.o_orderdate >= date '1994-03-01'
  and o.o_orderdate < date '1994-06-01'
  and l.l_returnflag = 'R'
  and c.c_nationkey = n.n_nationkey
group by
  c.c_custkey,
  c.c_name,
  c.c_acctbal,
  c.c_phone,
  n.n_name,
  c.c_address,
  c.c_comment
order by
  revenue desc
limit 20;
.timer off
.print S5_END_0
.print S5_COMPLETE
