.bail on
.echo off
.mode json
.timer off
CREATE VIEW customer AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/customer/part.0.parquet']);
CREATE VIEW lineitem AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.0.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.1.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.2.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.3.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.4.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.5.parquet']);
CREATE VIEW nation AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/nation/part.0.parquet']);
CREATE VIEW orders AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/orders/part.0.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/orders/part.1.parquet']);
CREATE VIEW part AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/part/part.0.parquet']);
CREATE VIEW partsupp AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/partsupp/part.0.parquet']);
CREATE VIEW region AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/region/part.0.parquet']);
CREATE VIEW supplier AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/supplier/part.0.parquet']);
.once "/home/ubuntu/sirius-s5-four-gpu/build/s5-four-gpu-results/all22/oracle/q4/schema.json"
DESCRIBE select
  o.o_orderpriority,
  count(*) as order_count
from
  orders o
where
  o.o_orderdate >= date '1996-10-01'
  and o.o_orderdate < date '1997-01-01'
  and
  exists (
    select
      *
    from
      lineitem l
    where
      l.l_orderkey = o.o_orderkey
      and l.l_commitdate < l.l_receiptdate
  )
group by
  o.o_orderpriority
order by
  o.o_orderpriority;
.print S5_BEGIN_0
.timer on 9
.once "/home/ubuntu/sirius-s5-four-gpu/build/s5-four-gpu-results/all22/oracle/q4/result-0.json"
select
  o.o_orderpriority,
  count(*) as order_count
from
  orders o
where
  o.o_orderdate >= date '1996-10-01'
  and o.o_orderdate < date '1997-01-01'
  and
  exists (
    select
      *
    from
      lineitem l
    where
      l.l_orderkey = o.o_orderkey
      and l.l_commitdate < l.l_receiptdate
  )
group by
  o.o_orderpriority
order by
  o.o_orderpriority;
.timer off
.print S5_END_0
.print S5_COMPLETE
