.bail on
.echo off
.mode json
.timer off
CREATE VIEW customer AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/customer/part.0.parquet']);
CREATE VIEW lineitem AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.0.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.1.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.2.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.3.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.4.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.5.parquet']);
CREATE VIEW nation AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/nation/part.0.parquet']);
CREATE VIEW orders AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/orders/part.0.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/orders/part.1.parquet']);
CREATE VIEW part AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/part/part.0.parquet']);
CREATE VIEW partsupp AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/partsupp/part.0.parquet']);
CREATE VIEW region AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/region/part.0.parquet']);
CREATE VIEW supplier AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/supplier/part.0.parquet']);
.once "/home/ubuntu/sirius-s5-four-gpu/build/s5-four-gpu-results/all22/oracle/q22/schema.json"
DESCRIBE select
  cntrycode,
  count(*) as numcust,
  sum(c_acctbal) as totacctbal
from
  (
    select
      substring(c_phone from 1 for 2) as cntrycode,
      c_acctbal
    from
      customer c
    where
      substring(c_phone from 1 for 2) in
        ('24', '31', '11', '16', '21', '20', '34')
      and c_acctbal > (
        select
          avg(c_acctbal)
        from
          customer
        where
          c_acctbal > 0.00
          and substring(c_phone from 1 for 2) in
            ('24', '31', '11', '16', '21', '20', '34')
      )
      and not exists (
        select
          *
        from
          orders o
        where
          o.o_custkey = c.c_custkey
      )
  ) as custsale
group by
  cntrycode
order by
  cntrycode;
.print S5_BEGIN_0
.timer on 9
.once "/home/ubuntu/sirius-s5-four-gpu/build/s5-four-gpu-results/all22/oracle/q22/result-0.json"
select
  cntrycode,
  count(*) as numcust,
  sum(c_acctbal) as totacctbal
from
  (
    select
      substring(c_phone from 1 for 2) as cntrycode,
      c_acctbal
    from
      customer c
    where
      substring(c_phone from 1 for 2) in
        ('24', '31', '11', '16', '21', '20', '34')
      and c_acctbal > (
        select
          avg(c_acctbal)
        from
          customer
        where
          c_acctbal > 0.00
          and substring(c_phone from 1 for 2) in
            ('24', '31', '11', '16', '21', '20', '34')
      )
      and not exists (
        select
          *
        from
          orders o
        where
          o.o_custkey = c.c_custkey
      )
  ) as custsale
group by
  cntrycode
order by
  cntrycode;
.timer off
.print S5_END_0
.print S5_COMPLETE
