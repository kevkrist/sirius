.bail on
.echo off
.mode json
.timer off
CREATE VIEW customer AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/customer/part.0.parquet']);
CREATE VIEW lineitem AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.0.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.1.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.2.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.3.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.4.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.5.parquet']);
CREATE VIEW nation AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/nation/part.0.parquet']);
CREATE VIEW orders AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/orders/part.0.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/orders/part.1.parquet']);
CREATE VIEW part AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/part/part.0.parquet']);
CREATE VIEW partsupp AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/partsupp/part.0.parquet']);
CREATE VIEW region AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/region/part.0.parquet']);
CREATE VIEW supplier AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/supplier/part.0.parquet']);
.once "/home/ubuntu/sirius-s5-four-gpu/build/s5-four-gpu-results/all22/oracle/q13/schema.json"
DESCRIBE select
  c_count,
  count(*) as custdist
from
  (
    select
      c.c_custkey,
      count(o.o_orderkey)
    from
      customer c
      left outer join orders o
        on c.c_custkey = o.o_custkey
        and o.o_comment not like '%special%requests%'
    group by
      c.c_custkey
  ) as orders (c_custkey, c_count)
group by
  c_count
order by
  custdist desc,
  c_count desc;
.print S5_BEGIN_0
.timer on 9
.once "/home/ubuntu/sirius-s5-four-gpu/build/s5-four-gpu-results/all22/oracle/q13/result-0.json"
select
  c_count,
  count(*) as custdist
from
  (
    select
      c.c_custkey,
      count(o.o_orderkey)
    from
      customer c
      left outer join orders o
        on c.c_custkey = o.o_custkey
        and o.o_comment not like '%special%requests%'
    group by
      c.c_custkey
  ) as orders (c_custkey, c_count)
group by
  c_count
order by
  custdist desc,
  c_count desc;
.timer off
.print S5_END_0
.print S5_COMPLETE
