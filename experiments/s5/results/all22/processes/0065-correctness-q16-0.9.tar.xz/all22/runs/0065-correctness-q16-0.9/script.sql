.bail on
.echo off
.mode json
.timer off
LOAD '/home/ubuntu/sirius-s5-four-gpu/sirius-duckdb/build/release/extension/sirius/sirius.duckdb_extension';
SET gpu_execution=false;
SET enable_duckdb_fallback=false;
SET enable_dynamic_filter=true;
SET enable_dynamic_filter_multi_partition=true;
SET max_dynamic_filter_bloom_bytes_per_gpu=268435456;
SET dynamic_filter_domain_coverage_threshold=0.9;
CREATE VIEW customer AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/customer/part.0.parquet']);
CREATE VIEW lineitem AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.0.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.1.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.2.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.3.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.4.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.5.parquet']);
CREATE VIEW nation AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/nation/part.0.parquet']);
CREATE VIEW orders AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/orders/part.0.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/orders/part.1.parquet']);
CREATE VIEW part AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/part/part.0.parquet']);
CREATE VIEW partsupp AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/partsupp/part.0.parquet']);
CREATE VIEW region AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/region/part.0.parquet']);
CREATE VIEW supplier AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/supplier/part.0.parquet']);
CALL pin_table('/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/part/*.parquet', name='part', tier='gpu', cols=['p_partkey','p_brand','p_type','p_size'], compression=false, unique_cols=>['p_partkey']);
CALL pin_table('/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/partsupp/*.parquet', name='partsupp', tier='gpu', cols=['ps_partkey','ps_suppkey'], compression=false);
CALL pin_table('/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/supplier/*.parquet', name='supplier', tier='gpu', cols=['s_suppkey','s_comment'], compression=false, unique_cols=>['s_suppkey']);
.once "/home/ubuntu/sirius-s5-four-gpu/build/s5-four-gpu-results/all22/runs/0065-correctness-q16-0.9/schema.json"
DESCRIBE select
  p.p_brand,
  p.p_type,
  p.p_size,
  count(distinct ps.ps_suppkey) as supplier_cnt
from
  partsupp ps,
  part p
where
  p.p_partkey = ps.ps_partkey
  and p.p_brand <> 'Brand#21'
  and p.p_type not like 'MEDIUM PLATED%'
  and p.p_size in (38, 2, 8, 31, 44, 5, 14, 24)
  and ps.ps_suppkey not in (
    select
      s.s_suppkey
    from
      supplier s
    where
      s.s_comment like '%Customer%Complaints%'
  )
group by
  p.p_brand,
  p.p_type,
  p.p_size
order by
  supplier_cnt desc,
  p.p_brand,
  p.p_type,
  p.p_size;
.once "/home/ubuntu/sirius-s5-four-gpu/build/s5-four-gpu-results/all22/runs/0065-correctness-q16-0.9/settings.json"
SELECT current_setting('enable_duckdb_fallback') AS fallback, current_setting('enable_dynamic_filter') AS enabled, current_setting('enable_dynamic_filter_multi_partition') AS multipartition, current_setting('max_dynamic_filter_bloom_bytes_per_gpu')::BIGINT AS cap, current_setting('dynamic_filter_domain_coverage_threshold') AS coverage;
SET gpu_execution=true;
.print S5_BEGIN_0
.timer on 9
.once "/home/ubuntu/sirius-s5-four-gpu/build/s5-four-gpu-results/all22/runs/0065-correctness-q16-0.9/result-0.json"
select
  p.p_brand,
  p.p_type,
  p.p_size,
  count(distinct ps.ps_suppkey) as supplier_cnt
from
  partsupp ps,
  part p
where
  p.p_partkey = ps.ps_partkey
  and p.p_brand <> 'Brand#21'
  and p.p_type not like 'MEDIUM PLATED%'
  and p.p_size in (38, 2, 8, 31, 44, 5, 14, 24)
  and ps.ps_suppkey not in (
    select
      s.s_suppkey
    from
      supplier s
    where
      s.s_comment like '%Customer%Complaints%'
  )
group by
  p.p_brand,
  p.p_type,
  p.p_size
order by
  supplier_cnt desc,
  p.p_brand,
  p.p_type,
  p.p_size;
.timer off
.print S5_END_0
.print S5_COMPLETE
