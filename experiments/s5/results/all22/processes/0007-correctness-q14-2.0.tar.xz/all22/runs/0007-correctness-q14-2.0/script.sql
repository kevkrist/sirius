.bail on
.echo off
.mode json
.timer off
LOAD '/home/ubuntu/sirius-s5-four-gpu/sirius-duckdb/build/release/extension/sirius/sirius.duckdb_extension';
SET gpu_execution=false;
SET enable_duckdb_fallback=false;
SET enable_dynamic_filter=true;
SET enable_dynamic_filter_multi_partition=true;
SET max_dynamic_filter_bloom_bytes_per_gpu=268435456;
SET dynamic_filter_domain_coverage_threshold=2.0;
CREATE VIEW customer AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/customer/part.0.parquet']);
CREATE VIEW lineitem AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.0.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.1.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.2.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.3.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.4.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.5.parquet']);
CREATE VIEW nation AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/nation/part.0.parquet']);
CREATE VIEW orders AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/orders/part.0.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/orders/part.1.parquet']);
CREATE VIEW part AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/part/part.0.parquet']);
CREATE VIEW partsupp AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/partsupp/part.0.parquet']);
CREATE VIEW region AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/region/part.0.parquet']);
CREATE VIEW supplier AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/supplier/part.0.parquet']);
CALL pin_table('/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/*.parquet', name='lineitem', tier='gpu', cols=['l_partkey','l_extendedprice','l_discount','l_shipdate'], compression=false);
CALL pin_table('/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/part/*.parquet', name='part', tier='gpu', cols=['p_partkey','p_type'], compression=false, unique_cols=>['p_partkey']);
.once "/home/ubuntu/sirius-s5-four-gpu/build/s5-four-gpu-results/all22/runs/0007-correctness-q14-2.0/schema.json"
DESCRIBE select
  100.00 * sum(case
    when p.p_type like 'PROMO%'
      then l.l_extendedprice * (1 - l.l_discount)
    else 0
  end) / sum(l.l_extendedprice * (1 - l.l_discount)) as promo_revenue
from
  lineitem l,
  part p
where
  l.l_partkey = p.p_partkey
  and l.l_shipdate >= date '1994-08-01'
  and l.l_shipdate < date '1994-09-01';
.once "/home/ubuntu/sirius-s5-four-gpu/build/s5-four-gpu-results/all22/runs/0007-correctness-q14-2.0/settings.json"
SELECT current_setting('enable_duckdb_fallback') AS fallback, current_setting('enable_dynamic_filter') AS enabled, current_setting('enable_dynamic_filter_multi_partition') AS multipartition, current_setting('max_dynamic_filter_bloom_bytes_per_gpu')::BIGINT AS cap, current_setting('dynamic_filter_domain_coverage_threshold') AS coverage;
SET gpu_execution=true;
.print S5_BEGIN_0
.timer on 9
.once "/home/ubuntu/sirius-s5-four-gpu/build/s5-four-gpu-results/all22/runs/0007-correctness-q14-2.0/result-0.json"
select
  100.00 * sum(case
    when p.p_type like 'PROMO%'
      then l.l_extendedprice * (1 - l.l_discount)
    else 0
  end) / sum(l.l_extendedprice * (1 - l.l_discount)) as promo_revenue
from
  lineitem l,
  part p
where
  l.l_partkey = p.p_partkey
  and l.l_shipdate >= date '1994-08-01'
  and l.l_shipdate < date '1994-09-01';
.timer off
.print S5_END_0
.print S5_COMPLETE
