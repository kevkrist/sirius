.bail on
.echo off
.mode json
.timer off
LOAD '/home/ubuntu/sirius-s5-four-gpu/sirius-duckdb/build/release/extension/sirius/sirius.duckdb_extension';
SET gpu_execution=false;
SET enable_duckdb_fallback=false;
SET enable_dynamic_filter=true;
SET enable_dynamic_filter_multi_partition=true;
SET max_dynamic_filter_bloom_bytes_per_gpu=268435456;
SET dynamic_filter_domain_coverage_threshold=0.45;
CREATE VIEW customer AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/customer/part.0.parquet']);
CREATE VIEW lineitem AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.0.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.1.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.2.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.3.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.4.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/part.5.parquet']);
CREATE VIEW nation AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/nation/part.0.parquet']);
CREATE VIEW orders AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/orders/part.0.parquet','/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/orders/part.1.parquet']);
CREATE VIEW part AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/part/part.0.parquet']);
CREATE VIEW partsupp AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/partsupp/part.0.parquet']);
CREATE VIEW region AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/region/part.0.parquet']);
CREATE VIEW supplier AS SELECT * FROM read_parquet(['/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/supplier/part.0.parquet']);
CALL pin_table('/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/lineitem/*.parquet', name='lineitem', tier='gpu', cols=['l_orderkey','l_shipmode','l_commitdate','l_receiptdate','l_shipdate'], compression=false);
CALL pin_table('/home/ubuntu/sirius-s5-four-gpu/test_datasets/tpch_parquet_sf100/orders/*.parquet', name='orders', tier='gpu', cols=['o_orderkey','o_orderpriority'], compression=false, unique_cols=>['o_orderkey']);
.once "/home/ubuntu/sirius-s5-four-gpu/build/s5-four-gpu-results/all22/runs/0022-correctness-q12-0.45/schema.json"
DESCRIBE select
  l.l_shipmode,
  sum(case
    when o.o_orderpriority = '1-URGENT'
      or o.o_orderpriority = '2-HIGH'
      then 1
    else 0
  end) as high_line_count,
  sum(case
    when o.o_orderpriority <> '1-URGENT'
      and o.o_orderpriority <> '2-HIGH'
      then 1
    else 0
  end) as low_line_count
from
  orders o,
  lineitem l
where
  o.o_orderkey = l.l_orderkey
  and l.l_shipmode in ('TRUCK', 'REG AIR')
  and l.l_commitdate < l.l_receiptdate
  and l.l_shipdate < l.l_commitdate
  and l.l_receiptdate >= date '1994-01-01'
  and l.l_receiptdate < date '1995-01-01'
group by
  l.l_shipmode
order by
  l.l_shipmode;
.once "/home/ubuntu/sirius-s5-four-gpu/build/s5-four-gpu-results/all22/runs/0022-correctness-q12-0.45/settings.json"
SELECT current_setting('enable_duckdb_fallback') AS fallback, current_setting('enable_dynamic_filter') AS enabled, current_setting('enable_dynamic_filter_multi_partition') AS multipartition, current_setting('max_dynamic_filter_bloom_bytes_per_gpu')::BIGINT AS cap, current_setting('dynamic_filter_domain_coverage_threshold') AS coverage;
SET gpu_execution=true;
.print S5_BEGIN_0
.timer on 9
.once "/home/ubuntu/sirius-s5-four-gpu/build/s5-four-gpu-results/all22/runs/0022-correctness-q12-0.45/result-0.json"
select
  l.l_shipmode,
  sum(case
    when o.o_orderpriority = '1-URGENT'
      or o.o_orderpriority = '2-HIGH'
      then 1
    else 0
  end) as high_line_count,
  sum(case
    when o.o_orderpriority <> '1-URGENT'
      and o.o_orderpriority <> '2-HIGH'
      then 1
    else 0
  end) as low_line_count
from
  orders o,
  lineitem l
where
  o.o_orderkey = l.l_orderkey
  and l.l_shipmode in ('TRUCK', 'REG AIR')
  and l.l_commitdate < l.l_receiptdate
  and l.l_shipdate < l.l_commitdate
  and l.l_receiptdate >= date '1994-01-01'
  and l.l_receiptdate < date '1995-01-01'
group by
  l.l_shipmode
order by
  l.l_shipmode;
.timer off
.print S5_END_0
.print S5_COMPLETE
